class Vehicle:
    @staticmethod
    def move():
        return "moving..."
