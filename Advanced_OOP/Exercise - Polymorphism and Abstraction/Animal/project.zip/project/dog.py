from abc import ABC

from project.animal import Animal


class Dog(Animal, ABC):
    def __repr__(self):
        return f"This is {self.name}. {self.name} is a {self.age} year old {self.gender} {self.__class__.__name__}"

    def make_sound(self):
        return "Woof!"